// data.js
// Спільна логіка отримання маніфесту сесій.
// Маніфест (manifest.json) лежить у тому ж GitHub-репозиторії, що й сайт.
// admin.html (локально) оновлює цей файл через GitHub API.
// Публічний сайт просто читає його як звичайний JSON-файл.

const CLOUD_NAME = 'dufkhpzeg'; // Cloudinary — тільки для фото

const GITHUB_OWNER = 'VladKrasavaFoto';
const GITHUB_REPO = 'Portfolo';
const GITHUB_BRANCH = 'main';
const MANIFEST_PATH = 'manifest.json';

function manifestRawUrl() {
  // Читаємо з власного домену сайту (Vercel), а не з GitHub raw CDN —
  // так швидше й без зайвого кешування на боці GitHub.
  // ?t=... обходить кеш браузера, щоб сайт завжди бачив свіжі дані.
  return `manifest.json?t=${Date.now()}`;
}

async function fetchManifest() {
  try {
    const res = await fetch(manifestRawUrl());
    if (!res.ok) return { sessions: {} }; // манiфесту ще нема — це нормально на старті
    const data = await res.json();
    return data && data.sessions ? data : { sessions: {} };
  } catch (e) {
    console.error('Не вдалося завантажити маніфест сесій:', e);
    return { sessions: {} };
  }
}

// --- Визначення типу медіа (фото/відео) прямо з Cloudinary-посилання ---
// Маніфест не потребує окремого поля "type" — Cloudinary сам кладе
// /video/upload/ або /image/upload/ у шлях залежно від типу файлу.

function isVideoUrl(url) {
  return typeof url === 'string' && url.includes('/video/upload/');
}

// Cloudinary вміє віддати кадр-прев'ю відео, якщо просто замінити розширення на .jpg
function videoPosterUrl(url) {
  return url.replace(/\.[a-zA-Z0-9]+(?=$|\?)/, '.jpg');
}
